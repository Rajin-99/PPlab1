using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace scientificcalapp.Pages;

public class IndexModel : PageModel
{
    private readonly ILogger<IndexModel> _logger;

    public IndexModel(ILogger<IndexModel> logger)
    {
        _logger = logger;
    }
    public void OnGet()
    {

    }

     public void OnPost()
    {
 
        if (Request.Method.Equals("POST", System.StringComparison.OrdinalIgnoreCase)){
 
            if(Request.Form["ADD"]=="ADD"){
 
                ViewData["summation"]=double.Parse(Request.Form["num1"])+double.Parse(Request.Form["num2"]);
 
            }
            
            if(Request.Form["SUB"]=="SUB"){
 
                ViewData["summation"]=double.Parse(Request.Form["num1"])-double.Parse(Request.Form["num2"]);
 
            }
            if(Request.Form["POW"]=="POW"){
 
                ViewData["summation"]=Math.Pow(double.Parse(Request.Form["num1"]),double.Parse(Request.Form["num2"]));
 
            }
            

            if(Request.Form["SQR"]=="SQR"){
 
                ViewData["summation"]=double.Parse(Request.Form["num1"])*double.Parse(Request.Form["num1"]);
                
            }
            if (Request.Form["MUL"] == "MUL"){

             ViewData["summation"] = double.Parse(Request.Form["num1"]) * double.Parse(Request.Form["num2"]);
            }
             if (Request.Form["DIV"] == "DIV"){
               double num1 = double.Parse(Request.Form["num1"]);
              double num2 = double.Parse(Request.Form["num2"]);

                 // Check if num2 is not zero to avoid division by zero error
               if (num2 != 0)
                   {
                   ViewData["summation"] = num1 / num2;
                     }
                   else
                  {
                 // Handle division by zero case
                  ViewData["summation"] = "Error: Division by zero";
                    }
             }
             if (Request.Form["SIN"] == "SIN")
                     {
                    double num1 = double.Parse(Request.Form["num1"]);
                       ViewData["summation"] = Math.Sin(num1);
                        }
             if (Request.Form["COS"] == "COS")
                          {
                            double num1 = double.Parse(Request.Form["num1"]);
                              ViewData["summation"] = Math.Cos(num1);
                            
                             }
            if (Request.Form["TAN"] == "TAN")
                                {
                            double num1 = double.Parse(Request.Form["num1"]);
                           ViewData["summation"] = Math.Tan(num1);
                                }
             if (Request.Form["LOG"] == "LOG")
                                    {
                                double num1 = double.Parse(Request.Form["num1"]);
    
    // Ensure num1 is positive for logarithm (Math.Log does not accept zero or negative)
                                 if (num1 > 0)
                         {
                              ViewData["summation"] = Math.Log(num1);
                                 }
                                else
                                {
                                   ViewData["summation"] = "Error: Input must be greater than 0";
                                   }
                                }








 
        }
 
 
    }
}
